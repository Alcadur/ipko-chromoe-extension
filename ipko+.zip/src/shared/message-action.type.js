const MessageActionType = {
    get getRecipients() { return 'getRecipients'; },
    get getLastPage() { return 'getLastPage'; }
}
