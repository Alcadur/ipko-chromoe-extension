const MessageActionType = {
    get getRecipients() { return 'getRecipients'; },
    get getLastPage() { return 'getLastPage'; },
    get enableGetRecipientButton() { return 'enableGetRecipientButton'; },
    get isGetRecipientFinished() { return 'isGetRecipientFinished'; },
    get isLoggedIn() { return 'isLoggedIn'; },
}
