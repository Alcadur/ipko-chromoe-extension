'use strict';

import { recipientEditControllerFactory } from './recipient-edit.controller.js';

recipientEditControllerFactory();
