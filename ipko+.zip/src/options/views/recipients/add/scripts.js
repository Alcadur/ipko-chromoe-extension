'use strict';

import { recipientAddControllerFactory } from './recipient-add.controller.js';

recipientAddControllerFactory();
