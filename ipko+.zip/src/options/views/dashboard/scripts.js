'use strict';

import { dashboardControllerFactory } from './dashboard.controller.js';

dashboardControllerFactory();
